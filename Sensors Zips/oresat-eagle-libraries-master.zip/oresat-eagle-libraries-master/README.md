# oresat-eagle-libraries
EAGLE CAD libraries for the OreSat CubeSat Project.

- Everything that is custom for OreSat has the "oresat-" prefix.
- Everything else starts with the reference designator:
   - R = resistor
   - D = diode
   - Q = Transistor
   - U = IC
   - ...etc...

Is this a good way to organize things? Well, probably not, but it makes it easy to find things. 
Ask us in a year or two if we hate it :)

