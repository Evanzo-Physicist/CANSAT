# SnapEDA-eagle-plugin
The instructions for installing the  SnapEDA Plugin for EAGLE (Alpha) are as follows:


1. In the folder you just downloaded, copy both 'snapeda.ulp' and 'json.inc' files.
2. Go to the Eagle application directory and navigate to the ulp folder, paste the files you copied into this folder
3. Copy the snapeda.png from the files you downloaded, paste into the bin folder of the Eagle application directory
4. Launch the Eagle application. In the Control Panel, go to File > Open > Scripts and open eagle.scr
5. Add the following line to the MENU area in BOTH the "BRD" and "SCH" sections:

'[snapeda.png] SnapEDA : Run snapeda.ulp;'\

6. Below is an example of what the BRD and SCH sections should look like:

BRD:
MENU '[designlink.png] Search and order : Run designlink-order.ulp -general;'\
     '[pcb-service.png] PCB Service : Run pcb-service.ulp;'\
     '[idf-3d.png] Export to IDF 3D format: Run eagleidfexporter.ulp;'\
     '[autodesk-make.png] Manufacture...: Run manufacturing.ulp;'\
     '[ecadio-logo.png] Export to ECAD.IO: Run ecadio.ulp;'\
     '[snapeda.png] SnapEDA : Run snapeda.ulp;'\
;

SCH:
Grid Default;
Change Width 0.006in;
MENU '[designlink.png] Search and order {\
                                          General : Run designlink-order.ulp -general; |\
                                          Schematic : Run designlink-order.ulp; \
                                          }'\
     '[snapeda.png] SnapEDA : Run snapeda.ulp;'\
;

7. The setup process is complete. To launch the SnapEDA plugin, create a new schematic or board, you should see the 'SnapEDA' icon in the top bar.
8. Note: if it does not appear, repeat step 5 but append 'bin/' in front of 'snapeda.png', i.e:

'[bin/snapeda.png] SnapEDA : Run snapeda.ulp;'\

9. If you have any questions, please contact us at info@snapeda.com