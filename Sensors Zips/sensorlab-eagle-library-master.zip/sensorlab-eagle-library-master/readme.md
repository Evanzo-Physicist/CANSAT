# Sensorlab Eagle parts library

Eagle library for all parts that we cannot find in other (common) Eagle
libraries.

## Parts

Complete list of parts, and link to Octopart page

* [Pro Signal MJ-2135 3.5mm PCB Mount phone audio connector, 4 connectors](https://octopart.com/mj-2135-pro+signal-42010560)

## License

This work is provided for others to use under the Creative Commons Legal 
Code Attribution-ShareAlike 3.0 Unported, see license.txt for details.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
